import pygame
import sys
from collections import deque

clock = pygame.time.Clock()

WIDTH, HEIGHT = 800, 600
FONT = None

WHITE = (240, 240, 240)
BLACK = (0, 0, 0)
BLUE = (100, 180, 255)
GREEN = (100, 230, 120)
RED = (255, 100, 100)
YELLOW = (255, 230, 100)
PURPLE = (180, 120, 255)
GREY = (180, 180, 180)


graph = {
    "A": ["B", "C"],
    "B": ["A", "D", "E"],
    "C": ["A", "F"],
    "D": ["B"],
    "E": ["B", "F"],
    "F": ["C", "E"]
}

positions = {
    "A": (400, 100),
    "B": (250, 220),
    "C": (550, 220),
    "D": (150, 380),
    "E": (350, 380),
    "F": (550, 380)
}


def draw_button(screen, text, rect):
    pygame.draw.rect(screen, (170, 170, 220), rect)
    pygame.draw.rect(screen, BLACK, rect, 2)

    label = FONT.render(text, True, BLACK)
    label_rect = label.get_rect(center=rect.center)
    screen.blit(label, label_rect)


def draw_graph(screen, visited=None, current=None, start_node=None, message=""):
    if visited is None:
        visited = []

    screen.fill(WHITE)

    title = FONT.render("Graph Traversal Visualiser - BFS and DFS", True, BLACK)
    screen.blit(title, (190, 30))

    info = FONT.render(message, True, BLACK)
    screen.blit(info, (80, 530))

    instruction = FONT.render("Click a node to choose start. Then click BFS or DFS.", True, BLACK)
    screen.blit(instruction, (150, 65))

    bfs_button = pygame.Rect(180, 470, 120, 40)
    dfs_button = pygame.Rect(340, 470, 120, 40)
    reset_button = pygame.Rect(500, 470, 120, 40)
    back_button = pygame.Rect(640, 470, 100, 40)

    draw_button(screen, "BFS", bfs_button)
    draw_button(screen, "DFS", dfs_button)
    draw_button(screen, "Reset", reset_button)
    draw_button(screen, "Back", back_button)

    drawn_edges = set()

    for node in graph:
        for neighbour in graph[node]:
            edge = tuple(sorted((node, neighbour)))

            if edge not in drawn_edges:
                pygame.draw.line(screen, BLACK, positions[node], positions[neighbour], 3)
                drawn_edges.add(edge)

    for node, pos in positions.items():
        color = BLUE

        if node in visited:
            color = YELLOW

        if node == current:
            color = RED

        if node == start_node:
            color = GREEN

        pygame.draw.circle(screen, color, pos, 28)
        pygame.draw.circle(screen, BLACK, pos, 28, 2)

        text = FONT.render(node, True, BLACK)
        text_rect = text.get_rect(center=pos)
        screen.blit(text, text_rect)

    pygame.display.flip()

    return bfs_button, dfs_button, reset_button, back_button


def get_clicked_node(mouse_pos):
    mx, my = mouse_pos

    for node, pos in positions.items():
        x, y = pos
        distance = ((mx - x) ** 2 + (my - y) ** 2) ** 0.5

        if distance <= 28:
            return node

    return None


def bfs_visualise(screen, start_node):
    visited = []
    queue = deque([start_node])
    seen = {start_node}

    while queue:
        current = queue.popleft()
        visited.append(current)

        draw_graph(
            screen,
            visited=visited,
            current=current,
            start_node=start_node,
            message="BFS visiting: " + current + " | Order: " + str(visited)
        )
        pygame.time.wait(700)

        for neighbour in graph[current]:
            if neighbour not in seen:
                seen.add(neighbour)
                queue.append(neighbour)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

    draw_graph(screen, visited=visited, start_node=start_node, message="BFS complete: " + str(visited))


def dfs_visualise(screen, start_node):
    visited = []
    stack = [start_node]
    seen = set()

    while stack:
        current = stack.pop()

        if current not in seen:
            seen.add(current)
            visited.append(current)

            draw_graph(
                screen,
                visited=visited,
                current=current,
                start_node=start_node,
                message="DFS visiting: " + current + " | Order: " + str(visited)
            )
            pygame.time.wait(700)

            for neighbour in reversed(graph[current]):
                if neighbour not in seen:
                    stack.append(neighbour)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

    draw_graph(screen, visited=visited, start_node=start_node, message="DFS complete: " + str(visited))


def run(screen):
    global FONT

    FONT = pygame.font.SysFont(None, 26)

    selected_start = None
    message = "No start node selected"
    running = True

    while running:
        bfs_button, dfs_button, reset_button, back_button = draw_graph(
            screen,
            start_node=selected_start,
            message=message
        )

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos

                clicked_node = get_clicked_node(pos)

                if clicked_node:
                    selected_start = clicked_node
                    message = "Selected start node: " + selected_start

                elif bfs_button.collidepoint(pos):
                    if selected_start:
                        bfs_visualise(screen, selected_start)
                        message = "BFS finished"
                    else:
                        message = "Select a start node first"

                elif dfs_button.collidepoint(pos):
                    if selected_start:
                        dfs_visualise(screen, selected_start)
                        message = "DFS finished"
                    else:
                        message = "Select a start node first"

                elif reset_button.collidepoint(pos):
                    selected_start = None
                    message = "Graph reset"

                elif back_button.collidepoint(pos):
                    running = False

        clock.tick(30)