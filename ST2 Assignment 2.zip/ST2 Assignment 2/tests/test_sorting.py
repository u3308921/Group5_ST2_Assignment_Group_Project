import unittest
from modules.sorting_visualiser import parse_input, connect_values


class TestSorting(unittest.TestCase):

    def test_bubble_sort_correctness(self):
        """Sort [5, 3, 8, 1, 2] — expected [1, 2, 3, 5, 8]"""
        array = [5, 3, 8, 1, 2]
        n = len(array)
        for i in range(n):
            for j in range(0, n - i - 1):
                if array[j] > array[j + 1]:
                    array[j], array[j + 1] = array[j + 1], array[j]
        self.assertEqual(array, [1, 2, 3, 5, 8])

    def test_selection_sort_correctness(self):
        """Sort [5, 3, 8, 1, 2] — expected [1, 2, 3, 5, 8]"""
        array = [5, 3, 8, 1, 2]
        n = len(array)
        for i in range(n):
            min_idx = i
            for j in range(i + 1, n):
                if array[j] < array[min_idx]:
                    min_idx = j
            array[i], array[min_idx] = array[min_idx], array[i]
        self.assertEqual(array, [1, 2, 3, 5, 8])

    def test_parse_input_valid(self):
        self.assertEqual(parse_input("5,3,8,1,2"), [5, 3, 8, 1, 2])

    def test_parse_input_with_spaces(self):
        self.assertEqual(parse_input("5, 3, 8"), [5, 3, 8])

    def test_parse_input_invalid(self):
        self.assertIsNone(parse_input("a,b,c"))

    def test_parse_input_empty(self):
        self.assertIsNone(parse_input(""))

    def test_connect_values_clamps(self):
        """Values should be clamped between 1 and 100"""
        self.assertEqual(connect_values([0, 200, 50]), [1, 100, 50])

    def test_connect_values_normal(self):
        self.assertEqual(connect_values([5, 3, 8]), [5, 3, 8])


if __name__ == "__main__":
    unittest.main()