import pygame
import sys
from modules.stack import Stack
from modules.queue_ds import Queue
from modules.linked_list import LinkedList
from modules.bst import BinarySearchTree


WIDTH, HEIGHT = 800, 600
clock = pygame.time.Clock()

BLOCK_WIDTH, BLOCK_HEIGHT = 200, 40
START_X = (WIDTH - BLOCK_WIDTH) // 2
BASE_Y = HEIGHT - BLOCK_HEIGHT - 20

QUEUE_BLOCK_WIDTH, QUEUE_BLOCK_HEIGHT = 80, 40
QUEUE_START_X = 120
QUEUE_Y = 260


def draw_button(screen, font, text, rect):
    pygame.draw.rect(screen, (150, 150, 220), rect)
    pygame.draw.rect(screen, (0, 0, 0), rect, 2)

    label = font.render(text, True, (0, 0, 0))
    label_rect = label.get_rect(center=rect.center)
    screen.blit(label, label_rect)


def stack_visualization(screen, font):
    stack = Stack()
    counter = 1
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    stack.push(counter)
                    counter += 1

                elif event.key == pygame.K_BACKSPACE and not stack.is_empty():
                    stack.pop()

                elif event.key == pygame.K_ESCAPE:
                    running = False

        screen.fill((50, 50, 50))

        for i, val in enumerate(stack._data):
            rect = pygame.Rect(START_X, BASE_Y - i * (BLOCK_HEIGHT + 5), BLOCK_WIDTH, BLOCK_HEIGHT)

            pygame.draw.rect(screen, (100, 150, 250), rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 2)

            text = font.render(str(val), True, (0, 0, 0))
            text_rect = text.get_rect(center=rect.center)
            screen.blit(text, text_rect)

        info_text = font.render("Spacebar = Push, backspace = Pop, Esc = return to menu", True, (200, 200, 200))
        screen.blit(info_text, (10, 10))

        pygame.display.flip()
        clock.tick(30)


def draw_queue(screen, font, queue, message):
    screen.fill((50, 50, 50))

    title = font.render("Queue Visualization", True, (255, 255, 255))
    screen.blit(title, (300, 60))

    front_text = font.render("Front", True, (255, 255, 255))
    rear_text = font.render("Rear", True, (255, 255, 255))
    screen.blit(front_text, (QUEUE_START_X, QUEUE_Y - 40))
    screen.blit(rear_text, (QUEUE_START_X + 500, QUEUE_Y - 40))

    for i, val in enumerate(queue._data):
        rect = pygame.Rect(QUEUE_START_X + i * (QUEUE_BLOCK_WIDTH + 10), QUEUE_Y, QUEUE_BLOCK_WIDTH, QUEUE_BLOCK_HEIGHT)

        pygame.draw.rect(screen, (100, 220, 150), rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)

        text = font.render(str(val), True, (0, 0, 0))
        text_rect = text.get_rect(center=rect.center)
        screen.blit(text, text_rect)

    enqueue_button = pygame.Rect(230, 430, 140, 45)
    dequeue_button = pygame.Rect(430, 430, 140, 45)

    draw_button(screen, font, "Enqueue", enqueue_button)
    draw_button(screen, font, "Dequeue", dequeue_button)

    info_text = font.render(
        "Click buttons to enqueue/dequeue. ESC: Return to menu",
        True,
        (200, 200, 200)
    )
    screen.blit(info_text, (150, 520))

    message_text = font.render(message, True, (255, 255, 255))
    screen.blit(message_text, (250, 130))

    return enqueue_button, dequeue_button

def queue_visualization(screen, font):
    queue = Queue()
    counter = 1
    message = "queue uses FIFO: first in, First out"
    running = True

    while running:
        enqueue_button, dequeue_button = draw_queue(screen, font, queue, message)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos

                if enqueue_button.collidepoint(pos):
                    queue.enqueue(counter)
                    message = "Enqueued " + str(counter)
                    counter += 1

                elif dequeue_button.collidepoint(pos):
                    if not queue.is_empty():
                        removed = queue.peek()
                        queue.dequeue()
                        message = "Dequeued " + str(removed)
                    else:
                        message = "Queue is empty"
                        
def linked_list_visualization(screen, font):
    linked_list = LinkedList()
    message = "Linked List: Insert, Delete Front, Reverse"
    running = True
    insert_button = pygame.Rect(120, 450, 140, 45)
    delete_button = pygame.Rect(330, 450, 140, 45)
    reverse_button = pygame.Rect(540, 450, 140, 45)

    #  textbox
    textbox_rect = pygame.Rect(120, 390, 140, 40)
    input_text = ""
    textbox_active = False

    while running:
        screen.fill((50, 50, 50))
        title = font.render("Linked List Visualization", True, (255, 255, 255))
        screen.blit(title, (280, 50))
        values = linked_list.to_list()
        start_x = 100
        y = 250
        node_width = 70
        node_height = 45
        gap = 40
        for i, value in enumerate(values):
            x = start_x + i * (node_width + gap)
            rect = pygame.Rect(x, y, node_width, node_height)
            pygame.draw.rect(screen, (255, 200, 100), rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 2)
            text = font.render(str(value), True, (0, 0, 0))
            text_rect = text.get_rect(center=rect.center)
            screen.blit(text, text_rect)

            
            index_text = font.render(str(i), True, (180, 220, 255))
            index_rect = index_text.get_rect(center=(rect.centerx, y - 20))
            screen.blit(index_text, index_rect)

            if i < len(values) - 1:
                arrow_start = (x + node_width, y + node_height // 2)
                arrow_end = (x + node_width + gap - 10, y + node_height // 2)
                pygame.draw.line(screen, (255, 255, 255), arrow_start, arrow_end, 3)
                pygame.draw.polygon(
                    screen,
                    (255, 255, 255),
                    [
                        (arrow_end[0], arrow_end[1]),
                        (arrow_end[0] - 10, arrow_end[1] - 6),
                        (arrow_end[0] - 10, arrow_end[1] + 6)
                    ]
                )
        label = font.render("Insert value:", True, (200, 200, 200))
        screen.blit(label, (120, 368))

        box_color = (255, 255, 255) if textbox_active else (180, 180, 180)
        pygame.draw.rect(screen, box_color, textbox_rect)
        pygame.draw.rect(screen, (0, 0, 0), textbox_rect, 2)
        input_surface = font.render(input_text, True, (0, 0, 0))
        screen.blit(input_surface, (textbox_rect.x + 8, textbox_rect.y + 8))

        draw_button(screen, font, "Insert", insert_button)
        draw_button(screen, font, "Delete", delete_button)
        draw_button(screen, font, "Reverse", reverse_button)
        info_text = font.render("ESC: Return to menu", True, (200, 200, 200))
        screen.blit(info_text, (300, 520))
        message_text = font.render(message, True, (255, 255, 255))
        screen.blit(message_text, (220, 120))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif textbox_active:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        # Insert on Enter key too
                        if input_text.lstrip("-").isdigit():
                            linked_list.insert_end(int(input_text))
                            message = f"Inserted node {input_text}"
                            input_text = ""
                        else:
                            message = "Please enter a valid integer"
                    elif event.unicode.lstrip("-").isdigit() or (event.unicode == "-" and input_text == ""):
                        if len(input_text) < 6:
                            input_text += event.unicode
            elif event.type == pygame.MOUSEBUTTONDOWN:
                position = event.pos
                textbox_active = textbox_rect.collidepoint(position)
                if insert_button.collidepoint(position):
                    if input_text.lstrip("-").isdigit():
                        linked_list.insert_end(int(input_text))
                        message = f"Inserted {input_text}"
                        input_text = ""
                    else:
                        message = "Enter a valid integer"
                elif delete_button.collidepoint(position):
                    if not linked_list.is_empty():
                        removed = linked_list.delete_front()
                        message = "deleted node " + str(removed)
                    else:
                        message = "Linked list is empty"
                elif reverse_button.collidepoint(position):
                    linked_list.reverse()
                    message = "Linked list reversed"
        clock.tick(30)
        
def draw_bst_node(screen, font, node, x, y, spacing):
    if node is None:
        return

    radius = 22

    if node.left is not None:
        left_x = x - spacing
        left_y = y + 80
        pygame.draw.line(screen, (255, 255, 255), (x, y), (left_x, left_y), 2)
        draw_bst_node(screen, font, node.left, left_x, left_y, spacing // 2)

    if node.right is not None:
        right_x = x + spacing
        right_y = y + 80
        pygame.draw.line(screen, (255, 255, 255), (x, y), (right_x, right_y), 2)
        draw_bst_node(screen, font, node.right, right_x, right_y, spacing // 2)

    pygame.draw.circle(screen, (120, 180, 255), (x, y), radius)
    pygame.draw.circle(screen, (0, 0, 0), (x, y), radius, 2)

    text = font.render(str(node.value), True, (0, 0, 0))
    text_rect = text.get_rect(center=(x, y))
    screen.blit(text, text_rect)


def bst_visualization(screen, font):
    bst = BinarySearchTree()
    values_to_insert = [50, 30, 70, 20, 40, 60, 80]
    index = 0
    traversal_text = "Traversal will appear here"
    message = "Click Insert to add BST nodes"
    running = True

    insert_button = pygame.Rect(90, 500, 120, 45)
    inorder_button = pygame.Rect(240, 500, 120, 45)
    preorder_button = pygame.Rect(390, 500, 130, 45)
    postorder_button = pygame.Rect(550, 500, 140, 45)

    while running:
        screen.fill((50, 50, 50))

        title = font.render("Binary Search Tree Visualization", True, (255, 255, 255))
        screen.blit(title, (230, 40))

        message_text = font.render(message, True, (255, 255, 255))
        screen.blit(message_text, (230, 85))

        traversal_display = font.render(traversal_text, True, (255, 255, 255))
        screen.blit(traversal_display, (80, 440))

        if bst.root is not None:
            draw_bst_node(screen, font, bst.root, 400, 150, 160)

        draw_button(screen, font, "Insert", insert_button)
        draw_button(screen, font, "Inorder", inorder_button)
        draw_button(screen, font, "Preorder", preorder_button)
        draw_button(screen, font, "Postorder", postorder_button)

        info_text = font.render("ESC: Return to menu", True, (200, 200, 200))
        screen.blit(info_text, (300, 560))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos

                if insert_button.collidepoint(pos):
                    if index < len(values_to_insert):
                        value = values_to_insert[index]
                        bst.insert(value)
                        message = "Inserted node " + str(value)
                        index += 1
                    else:
                        message = "All sample BST nodes inserted"

                elif inorder_button.collidepoint(pos):
                    traversal_text = "Inorder: " + str(bst.inorder())

                elif preorder_button.collidepoint(pos):
                    traversal_text = "Preorder: " + str(bst.preorder())

                elif postorder_button.collidepoint(pos):
                    traversal_text = "Postorder: " + str(bst.postorder())

        clock.tick(30)


def run(screen):
    font = pygame.font.SysFont(None, 28)

    menu_items = [
        "Stack Visualization",
        "Queue Visualization",
        "Linked List Visualization",
        "BST Visualization",
        "Back"
    ]

    selected = 0
    running = True

    while running:
        screen.fill((200, 200, 250))

        for i, item in enumerate(menu_items):
            highlight = (5, 100, 150) if i == selected else (0, 0, 0)
            text = font.render(item, True, highlight)
            screen.blit(text, (100, 100 + i * 40))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)

                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)

                elif event.key == pygame.K_RETURN:
                    choice = menu_items[selected]

                    if choice == "Stack Visualization":
                        stack_visualization(screen, font)
                    
                    elif choice == "Queue Visualization":
                        queue_visualization(screen, font)
                    
                    elif choice == "Linked List Visualization":
                        linked_list_visualization(screen, font)
                    
                    elif choice == "BST Visualization":
                        bst_visualization(screen, font)
                    
                    elif choice == "Back":
                        running = False

        clock.tick(30)