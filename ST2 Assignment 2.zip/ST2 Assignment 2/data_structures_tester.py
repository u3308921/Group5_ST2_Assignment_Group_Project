import pygame
import sys

pygame.init()

from modules import data_structures_visualiser
from modules import sorting_visualiser
from modules import graph_visualiser
from modules import heap_visualiser
from modules import puzzle_visualiser


WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Algorithm Explorer")

FONT = pygame.font.SysFont(None, 36)
clock = pygame.time.Clock()


def draw_text(text, pos):
    txt_surface = FONT.render(text, True, (0, 0, 0))
    screen.blit(txt_surface, pos)


def main_menu():
    screen.fill((200, 200, 250))
    draw_text("Algorithm Explorer", (WIDTH // 3, 50))

    buttons = {
        "Data Structures": pygame.Rect(300, 120, 220, 50),
        "Sorting": pygame.Rect(300, 190, 220, 50),
        "Graphs": pygame.Rect(300, 260, 220, 50),
        "Heap": pygame.Rect(300, 330, 220, 50),
        "Puzzles": pygame.Rect(300, 400, 220, 50),
        "Exit": pygame.Rect(300, 470, 220, 50),
        }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, (150, 150, 200), rect)
        draw_text(text, (rect.x + 20, rect.y + 10))

    pygame.display.flip()
    return buttons


def main():
    running = True
    current_module = None

    while running:
        if current_module is None:
            buttons = main_menu()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos

                    for name, rect in buttons.items():
                        if rect.collidepoint(pos):
                            if name == "Exit":
                                running = False
                            elif name == "Data Structures":
                                current_module = name
                            elif name == "Sorting":
                                current_module = name
                            elif name == "Puzzles":
                                current_module = name
                            elif name == "Heap":
                                current_module = name
                            elif name == "Graphs":
                                current_module = name
                            else:
                                pass

        else:
            try:
                if current_module == "Data Structures":
                    data_structures_visualiser.run(screen)  
                elif current_module == "Sorting":
                    sorting_visualiser.run(screen)
                elif current_module == "Puzzles":
                    puzzle_visualiser.run(screen)
                elif current_module == "Graphs":
                    graph_visualiser.run(screen)
                elif current_module == "Heap":
                    heap_visualiser.run(screen)

            except SystemExit:
                running = False
                break

            finally:
                current_module = None

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()