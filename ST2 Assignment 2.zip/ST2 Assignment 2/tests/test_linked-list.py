import unittest
from modules.linked_list import LinkedList


class TestLinkedList(unittest.TestCase):

    def test_insert_node_at_position_2(self):
        """Insert value 10 at position 2 — node present in correct location"""
        ll = LinkedList()
        ll.insert_end(5)
        ll.insert_end(10)  # position 2 (index 1)
        ll.insert_end(20)
        self.assertEqual(ll.to_list()[1], 10)

    def test_insert_end_order(self):
        ll = LinkedList()
        ll.insert_end(1)
        ll.insert_end(2)
        ll.insert_end(3)
        self.assertEqual(ll.to_list(), [1, 2, 3])

    def test_delete_front(self):
        ll = LinkedList()
        ll.insert_end(1)
        ll.insert_end(2)
        removed = ll.delete_front()
        self.assertEqual(removed, 1)
        self.assertEqual(ll.to_list(), [2])

    def test_delete_front_empty_raises(self):
        ll = LinkedList()
        with self.assertRaises(IndexError):
            ll.delete_front()

    def test_is_empty(self):
        ll = LinkedList()
        self.assertTrue(ll.is_empty())
        ll.insert_end(1)
        self.assertFalse(ll.is_empty())

    def test_reverse(self):
        ll = LinkedList()
        ll.insert_end(1)
        ll.insert_end(2)
        ll.insert_end(3)
        ll.reverse()
        self.assertEqual(ll.to_list(), [3, 2, 1])


if __name__ == "__main__":
    unittest.main()