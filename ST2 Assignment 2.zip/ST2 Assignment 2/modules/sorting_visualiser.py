import pygame
import random
import sys

WIDTH, HEIGHT = 800, 600
FONT = None
clock = pygame.time.Clock()

ARRAY_SIZE = 30
bar_width = WIDTH // ARRAY_SIZE


def get_array(screen):
    input_text = ""
    active = True
    error_msg = ""

    input_box = pygame.Rect(40, 260, 720, 44)
    confirm_button = pygame.Rect(300, 330, 200, 44)

    while active:
        screen.fill((30, 30, 30))

        title = FONT.render("Enter your array", True, (180, 180, 220))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 160))

        instructions = FONT.render("Type integers separated by commas  (e.g. 5, 3, 8, 1, 2)", True, (160, 160, 160))
        screen.blit(instructions, (WIDTH // 2 - instructions.get_width() // 2, 210))



        pygame.draw.rect(screen, (50, 50, 70), input_box, border_radius=6)
        pygame.draw.rect(screen, (180, 180, 220), input_box, 2, border_radius=6)
        input_surface = FONT.render(input_text, True, (255, 255, 255))
        screen.blit(input_surface, (input_box.x + 10, input_box.y + 12))

        if pygame.time.get_ticks() % 1000 < 500:
            cursor_x = input_box.x + 10 + input_surface.get_width() + 2
            pygame.draw.line(screen, (200, 200, 200),
                             (cursor_x, input_box.y + 8),
                             (cursor_x, input_box.y + 36), 2)

        pygame.draw.rect(screen, (80, 160, 100), confirm_button, border_radius=6)
        pygame.draw.rect(screen, (0, 0, 0), confirm_button, 2, border_radius=6)
        confirm_label = FONT.render("Confirm", True, (0, 0, 0))
        screen.blit(confirm_label, confirm_label.get_rect(center=confirm_button.center))

        if error_msg:
            err_surface = FONT.render(error_msg, True, (255, 100, 100))
            screen.blit(err_surface, (WIDTH // 2 - err_surface.get_width() // 2, 390))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    result = parse_input(input_text)
                    if result is None:
                        error_msg = "Ensure integers are separated by commas"
                    elif len(result) < 2:
                        error_msg = "Enter at least 2 integers"
                    else:
                        return connect_values(result)
                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]
                    error_msg = ""
                else:
                    input_text += event.unicode
                    error_msg = ""

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                if confirm_button.collidepoint(pos):
                    result = parse_input(input_text)
                    if result is None:
                        error_msg = "Invalid input — use integers separated by commas."
                    elif len(result) < 2:
                        error_msg = "Please enter at least 2 integers."
                    else:
                        return connect_values(result)

        clock.tick(30)


def parse_input(text):
    #Parse the string of integers thats seperated by commas
    try:
        parts = [p.strip() for p in text.split(",") if p.strip()]
        if not parts:
            return None
        return [int(p) for p in parts]
    except ValueError:
        return None

def connect_values(values):
    connected = [max(1, min(100, abs(v))) for v in values]
    return connected


def draw_button(screen, text, rect):
    pygame.draw.rect(screen, (180, 180, 220), rect)
    pygame.draw.rect(screen, (0, 0, 0), rect, 2)
    label = FONT.render(text, True, (0, 0, 0))
    label_rect = label.get_rect(center=rect.center)
    screen.blit(label, label_rect)


def draw_array(screen, array, colour_positions=None, message=""):
    screen.fill((30, 30, 30))

    #sorting options
    bubble_button    = pygame.Rect(40,  20, 110, 40)
    selection_button = pygame.Rect(170, 20, 130, 40)
    merge_button     = pygame.Rect(320, 20, 110, 40)
    reset_button     = pygame.Rect(450, 20, 100, 40)
    back_button      = pygame.Rect(570, 20, 100, 40)

    draw_button(screen, "Bubble",    bubble_button)
    draw_button(screen, "Selection", selection_button)
    draw_button(screen, "Merge",     merge_button)
    draw_button(screen, "Reset",     reset_button)
    draw_button(screen, "Back",      back_button)

    message_text = FONT.render(message, True, (255, 255, 255))
    screen.blit(message_text, (40, 560))

    n = len(array)
    padding = 8
    box_h = 50
    available_w = WIDTH - 2 * padding
    box_w = max(30, min(80, (available_w - padding * (n - 1)) // n))
    total_w = n * box_w + (n - 1) * padding
    start_x = (WIDTH - total_w) // 2
    box_y = HEIGHT // 2 - box_h // 2 

    #Utilising colours to show selected items
    for i, val in enumerate(array):
        if colour_positions and i in colour_positions.get("swap", []):
            bg_colour = (80, 220, 100)
            text_colour = (0, 0, 0)
        elif colour_positions and i in colour_positions.get("compare", []):
            bg_colour = (220, 80, 80)
            text_colour = (255, 255, 255)
        elif colour_positions and i in colour_positions.get("merge", []):
            bg_colour = (200, 170, 60)
            text_colour = (0, 0, 0)
        else:
            bg_colour = (70, 120, 180)
            text_colour = (255, 255, 255)

        x = start_x + i * (box_w + padding)
        box_rect = pygame.Rect(x, box_y, box_w, box_h)

        pygame.draw.rect(screen, bg_colour, box_rect, border_radius=6)
        pygame.draw.rect(screen, (200, 200, 200), box_rect, 2, border_radius=6)

        val_surface = FONT.render(str(val), True, text_colour)
        val_rect = val_surface.get_rect(center=box_rect.center)
        screen.blit(val_surface, val_rect)

    pygame.display.flip()
    return bubble_button, selection_button, merge_button, reset_button, back_button


def check_events_during_sort():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def bubble_sort_visualize(screen, array):
    n = len(array)
    for i in range(n):
        for j in range(0, n - i - 1):
            check_events_during_sort()
            draw_array(screen, array,{"compare": [j, j + 1], "swap": [], "merge": []},"Bubble Sort: comparing adjacent values")
            pygame.time.wait(140)
            if array[j] > array[j + 1]:
                array[j], array[j + 1] = array[j + 1], array[j]
                draw_array(screen, array,{"compare": [], "swap": [j, j + 1], "merge": []},"Bubble Sort: swapped values")
                pygame.time.wait(140)
    draw_array(screen, array, message="Bubble Sort complete")


def selection_sort_visualize(screen, array):
    n = len(array)
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            check_events_during_sort()
            draw_array(screen, array,{"compare": [min_index, j], "swap": [], "merge": []},"Selection Sort: finding smallest value")
            pygame.time.wait(140)
            if array[j] < array[min_index]:
                min_index = j
        if min_index != i:
            array[i], array[min_index] = array[min_index], array[i]
            draw_array(screen, array,{"compare": [], "swap": [i, min_index], "merge": []},"Selection Sort: swapped smallest value")
            pygame.time.wait(2000)
    draw_array(screen, array, message="Selection Sort complete")


def merge_sort_visualize(screen, array, left, right):
    if left >= right:
        return
    mid = (left + right) // 2
    draw_array(screen, array,{"compare": [], "swap": [], "merge": list(range(left, right + 1))},"Merge Sort: splitting section")
    pygame.time.wait(150)
    merge_sort_visualize(screen, array, left, mid)
    merge_sort_visualize(screen, array, mid + 1, right)
    merge(screen, array, left, mid, right)


def merge(screen, array, left, mid, right):
    left_part  = array[left:mid + 1]
    right_part = array[mid + 1:right + 1]
    i = j = 0
    k = left

    while i < len(left_part) and j < len(right_part):
        check_events_during_sort()
        draw_array(screen, array,
                   {"compare": [k], "swap": [], "merge": list(range(left, right + 1))},
                   "Merge Sort: merging values")
        pygame.time.wait(140)
        if left_part[i] <= right_part[j]:
            array[k] = left_part[i]; i += 1
        else:
            array[k] = right_part[j]; j += 1
        k += 1

    while i < len(left_part):
        check_events_during_sort()
        array[k] = left_part[i]
        draw_array(screen, array,{"compare": [], "swap": [k], "merge": list(range(left, right + 1))},"Merge Sort: adding remaining left values")
        pygame.time.wait(140)
        i += 1; k += 1

    while j < len(right_part):
        check_events_during_sort()
        array[k] = right_part[j]
        draw_array(screen, array,{"compare": [], "swap": [k], "merge": list(range(left, right + 1))},"Merge Sort: adding remaining right values")
        pygame.time.wait(140)
        j += 1; k += 1


def run(screen):
    global FONT

    FONT = pygame.font.SysFont(None, 24)

    array = get_array(screen)

    running = True

    while running:
        bubble_button, selection_button, merge_button, reset_button, back_button = draw_array(
            screen, array)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos

                if bubble_button.collidepoint(pos):
                    bubble_sort_visualize(screen, array)

                elif selection_button.collidepoint(pos):
                    selection_sort_visualize(screen, array)

                elif merge_button.collidepoint(pos):
                    merge_sort_visualize(screen, array, 0, len(array) - 1)
                    draw_array(screen, array, message="Merge Sort complete")

                elif reset_button.collidepoint(pos):
                    array = get_array(screen)

                elif back_button.collidepoint(pos):
                    running = False


        clock.tick(30)




if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Sorting Visualizer")
    run(screen)