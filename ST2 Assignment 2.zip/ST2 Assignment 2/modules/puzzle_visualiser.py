import pygame
import sys
import random
import heapq
from collections import deque

clock = pygame.time.Clock()

WIDTH, HEIGHT = 800, 600
FONT = None

WHITE = (240, 240, 240)
BLACK = (0, 0, 0)
GREY = (180, 180, 180)
DARK = (40, 40, 40)
BLUE = (100, 180, 255)
GREEN = (100, 230, 120)
RED = (255, 100, 100)
YELLOW = (255, 230, 100)
PURPLE = (180, 120, 255)


def draw_button(screen, text, rect):
    pygame.draw.rect(screen, (170, 170, 220), rect)
    pygame.draw.rect(screen, BLACK, rect, 2)

    label = FONT.render(text, True, BLACK)
    label_rect = label.get_rect(center=rect.center)
    screen.blit(label, label_rect)

#Pathfinding Puzzle using BFS

def pathfinding_puzzle(screen):
    rows, cols = 15, 20
    cell_size = 30
    grid_x = 80
    grid_y = 80
    weights = {(r, c): random.randint(1, 9) for r in range(rows) for c in range(cols)}


    start = None
    end = None
    obstacles = set()
    path = []
    message = "Left click: Start/End/Obstacle | SPACE: Run BFS | R: Reset | ESC: Back"
    ans = ""

    running = True

    while running:
        screen.fill(WHITE)

        title = FONT.render("Pathfinding Puzzle - BFS Shortest Path", True, BLACK)
        screen.blit(title, (210, 25))

        msg = FONT.render(message, True, BLACK)
        screen.blit(msg, (70, 540))

        result = FONT.render(ans, True, BLACK)
        screen.blit(result, (70, 580))

        small_font = pygame.font.SysFont(None, 18)

        for r in range(rows):
            for c in range(cols):
                rect = pygame.Rect(grid_x + c * cell_size, grid_y + r * cell_size, cell_size, cell_size)

                color = WHITE
                if (r, c) in obstacles:
                    color = DARK
                if (r, c) in path:
                    color = YELLOW
                if start == (r, c):
                    color = GREEN
                if end == (r, c):
                    color = RED

                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, GREY, rect, 1)

                if (r, c) not in obstacles and (r, c) != start and (r, c) != end:
                    w_text = small_font.render(str(weights[(r, c)]), True, (150, 150, 150))
                    w_rect = w_text.get_rect(center=rect.center)
                    screen.blit(w_text, w_rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_r:
                    start = None
                    end = None
                    obstacles.clear()
                    path = []
                    ans = "Grid reset"

                elif event.key == pygame.K_SPACE:
                    if start and end:
                        path = dijkstra_pathfinding(screen, rows, cols, start, end, obstacles, grid_x, grid_y, cell_size, weights)
                        if path:
                            ans = "Shortest path found"
                        else:
                            ans = "No path found"
                    else:
                        ans = "Place both start and end first"

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                c = (mx - grid_x) // cell_size
                r = (my - grid_y) // cell_size

                if 0 <= r < rows and 0 <= c < cols:
                    cell = (r, c)

                    if not start:
                        start = cell
                        ans = "Start placed"
                    elif not end and cell != start:
                        end = cell
                        ans = "End placed"
                    elif cell != start and cell != end:
                        if cell in obstacles:
                            obstacles.remove(cell)
                        else:
                            obstacles.add(cell)

        clock.tick(30)


def dijkstra_pathfinding(screen, rows, columns, start, end, obstacles, grid_x, grid_y, cell_size, weights):
    heap = [(0, start)]
    dist = {(r, c): float('inf') for r in range(rows) for c in range(columns)}
    dist[start] = 0
    parents = {start: []}
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    while heap:
        current_cost, current = heapq.heappop(heap)

        if current_cost > dist[current]:
            continue

        for dr, dc in directions:
            nr = current[0] + dr
            nc = current[1] + dc
            neighbour = (nr, nc)

            if 0 <= nr < rows and 0 <= nc < columns and neighbour not in obstacles:
                new_cost = dist[current] + weights[neighbour]

                if new_cost < dist[neighbour]:
                    dist[neighbour] = new_cost
                    parents[neighbour] = [current]
                    heapq.heappush(heap, (new_cost, neighbour))

                    rect = pygame.Rect(grid_x + nc * cell_size, grid_y + nr * cell_size, cell_size, cell_size)
                    pygame.draw.rect(screen, BLUE, rect)
                    pygame.draw.rect(screen, GREY, rect, 1)
                    pygame.display.flip()
                    pygame.time.wait(20)

                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()

                elif new_cost == dist[neighbour]:
                    parents[neighbour].append(current)

    if end not in parents or dist[end] == float('inf'):
        return []
    
    all_paths = []
    seen_paths = set()

    def reconstruct(node, path):
        if node == start:
            full_path = list(reversed(path + [node]))
            path_key = tuple(full_path)
            if path_key not in seen_paths:
                seen_paths.add(path_key)
                all_paths.append(full_path)
            return
        for p in parents[node]:
            reconstruct(p, path + [node])

    reconstruct(end, [])

    if not all_paths:
        return []

    all_paths.sort(key=lambda p: len(p))
    return all_paths[0]



#Event Queue Simulator using Heap



def event_queue_simulator(screen):
    events = []
    counter = 1
    message = "A: Add event | P: Process next event | R: Reset | ESC: Back"
    running = True

    while running:
        screen.fill((200, 200, 250))

        title = FONT.render("Event Queue Simulator - Heap Priority Queue", True, BLACK)
        screen.blit(title, (180, 40))

        info = FONT.render(message, True, BLACK)
        screen.blit(info, (130, 520))

        explanation = FONT.render("Less prioritised number is processed first", True, BLACK)
        screen.blit(explanation, (210, 85))

        sorted_events = sorted(events)

        x = 100
        y = 180

        for i, event in enumerate(sorted_events):
            priority, time_value, name = event

            rect = pygame.Rect(x, y + i * 55, 600, 40)
            pygame.draw.rect(screen, YELLOW, rect)
            pygame.draw.rect(screen, BLACK, rect, 2)

            text = FONT.render(
                f"{name} | Priority: {priority} | Time: {time_value}",
                True,
                BLACK
            )
            screen.blit(text, (rect.x + 20, rect.y + 10))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_a:
                    priority = (counter * 3) % 10 + 1
                    time_value = counter
                    name = "Event " + str(counter)

                    heapq.heappush(events, (priority, time_value, name))
                    message = "Added " + name
                    counter += 1

                elif event.key == pygame.K_p:
                    if events:
                        priority, time_value, name = heapq.heappop(events)
                        message = "Processed " + name
                    else:
                        message = "No events to process"

                elif event.key == pygame.K_r:
                    events.clear()
                    counter = 1
                    message = "Event queue reset"

        clock.tick(30)

#Dynamic Programming Grid Path Counting
def dynamic_programming_puzzle(screen):
    rows, cols = 8, 10
    cell_size = 45
    grid_x = 170
    grid_y = 90

    obstacles = set()
    dp = [[0 for _ in range(cols)] for _ in range(rows)]
    message = "Click cells to place obstacles | SPACE: Count paths | R: Reset | ESC: Back"

    running = True

    while running:
        screen.fill(WHITE)

        title = FONT.render("Dynamic Programming Puzzle - Grid Path Counting", True, BLACK)
        screen.blit(title, (160, 30))

        msg = FONT.render(message, True, BLACK)
        screen.blit(msg, (90, 530))

        for r in range(rows):
            for c in range(cols):
                rect = pygame.Rect(grid_x + c * cell_size, grid_y + r * cell_size, cell_size, cell_size)

                color = WHITE

                if (r, c) in obstacles:
                    color = DARK
                elif dp[r][c] > 0:
                    color = BLUE

                if (r, c) == (0, 0):
                    color = GREEN

                if (r, c) == (rows - 1, cols - 1):
                    color = RED

                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, GREY, rect, 1)

                if dp[r][c] > 0:
                    text = FONT.render(str(dp[r][c]), True, BLACK)
                    text_rect = text.get_rect(center=rect.center)
                    screen.blit(text, text_rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_r:
                    obstacles.clear()
                    dp = [[0 for _ in range(cols)] for _ in range(rows)]
                    message = "Grid reset"

                elif event.key == pygame.K_SPACE:
                    dp = run_dp_path_count(screen, rows, cols, obstacles, grid_x, grid_y, cell_size)
                    message = "Total paths: " + str(dp[rows - 1][cols - 1])

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                c = (mx - grid_x) // cell_size
                r = (my - grid_y) // cell_size

                if 0 <= r < rows and 0 <= c < cols:
                    cell = (r, c)

                    if cell != (0, 0) and cell != (rows - 1, cols - 1):
                        if cell in obstacles:
                            obstacles.remove(cell)
                        else:
                            obstacles.add(cell)

        clock.tick(30)


def run_dp_path_count(screen, rows, cols, obstacles, grid_x, grid_y, cell_size):
    dp = [[0 for _ in range(cols)] for _ in range(rows)]

    if (0, 0) not in obstacles:
        dp[0][0] = 1

    for r in range(rows):
        for c in range(cols):
            if (r, c) in obstacles:
                dp[r][c] = 0
                continue

            if r == 0 and c == 0:
                continue

            from_top = dp[r - 1][c] if r > 0 else 0
            from_left = dp[r][c - 1] if c > 0 else 0

            dp[r][c] = from_top + from_left

            rect = pygame.Rect(grid_x + c * cell_size, grid_y + r * cell_size, cell_size, cell_size)
            pygame.draw.rect(screen, BLUE, rect)
            pygame.draw.rect(screen, GREY, rect, 1)

            text = FONT.render(str(dp[r][c]), True, BLACK)
            text_rect = text.get_rect(center=rect.center)
            screen.blit(text, text_rect)

            pygame.display.flip()
            pygame.time.wait(80)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

    return dp


#menu

def run(screen):
    global FONT

    FONT = pygame.font.SysFont(None, 26)

    menu_items = ["Pathfinding Puzzle", "Event Queue Simulator", "Dynamic Programming Puzzle", "Back"]

    selected = 0
    running = True

    while running:
        screen.fill((220, 220, 240))

        title = FONT.render("Puzzle Challenges", True, BLACK)
        screen.blit(title, (280, 70))

        for i, item in enumerate(menu_items):
            color = RED if i == selected else BLACK
            text = FONT.render(item, True, color)
            screen.blit(text, (280, 160 + i * 50))

        instructions = FONT.render("Use UP/DOWN and ENTER. ESC also returns.", True, BLACK)
        screen.blit(instructions, (220, 500))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)

                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)

                elif event.key == pygame.K_RETURN:
                    choice = menu_items[selected]

                    if choice == "Pathfinding Puzzle":
                        pathfinding_puzzle(screen)

                    elif choice == "Event Queue Simulator":
                        event_queue_simulator(screen)

                    elif choice == "Dynamic Programming Puzzle":
                        dynamic_programming_puzzle(screen)

                    elif choice == "Back":
                        running = False

        clock.tick(30)